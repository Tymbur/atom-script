#!/usr/bin/env python2.7
import sys

print(sys.version_info)
