package main

import "fmt"

func main() {
	fmt.Println("Hello, 世界")
}
